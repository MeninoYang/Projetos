# Graficos

Description.
The package Graficos is used to:
    basic plotting functionalities using Matplotlib.

## Installation
Use the package manager pip to install Graficos


## Usage

from graficos import plotagem
file1_name.my_function()

## Author
Yang

## License
[MIT](https://choosealicense.com/licenses/mit/)